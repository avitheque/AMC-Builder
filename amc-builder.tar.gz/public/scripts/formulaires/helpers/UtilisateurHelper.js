/**
 * JavaScript relatif à la création d'un formulaire UTILISATEUR
 */